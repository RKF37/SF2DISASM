==Shining Force II RPG Season 1==

This is a community mod with custom characters created by the shining force community and coded into the game using the DISASM system. Each characters was created using a character creation process simular to a Table Top RPG. This system was created by lavathor.

The game has been tested with the Fusion Emulator, and Bizhawk systems, other systems have not been tested.

The characters were then coded into the game, and graphics were made and added as well. Many other changes were added as well. The majority of the work was done by lavathor (me) who came up with this mod idea and pushed for the community to help with it. This project wouldn't have been possible without the help of the following people:

Character Creators:
-lavathor
-Chaoswizard98
-Gryphonblade77
-Tyadran
-Sapphire
-CodeEden
-MuF
-Didakus
-Nihil
-Keif
-MXC
-GlacialGuy
-Quickdashattack
-sedpaul

Special thanks to:
-lavathor (me) for the coding and implementation as a whole
-GlacialGuy and sedpaul for helping me fix the many issues and bugs, couldn't have done it without them.
-CodeEden (and the other artists) that made such beautiful new graphics.
-Sapphire for finding so many bugs and doing so much bug testing.
And to everyone else involved!

Additonal thanks
-Shining Fanwork Discord
-Shining Force Central
-Shining Mods Forum
-Wolfgangarchive


